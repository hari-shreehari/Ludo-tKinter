from tkinter import *
from tkinter import messagebox
import random

ws = Tk()
ws.title('Ludo')
ws.geometry('1920x1080')
ws.config(bg='#141414')

#message
messagebox.showinfo("Instructions : ",
                    '''Game proceded with 4 players in rounds
Dice should roll 1 to take a coin out
No 2nd chance of dice roll is provided for any number cast on dice
Coins are moved by itself as per preloaded priorities ''')

#play turn
lastplayer_frame = Frame(ws,bg='#141414',highlightbackground="yellow",highlightthickness=4)
rolledplayer_label = Label(lastplayer_frame, text = f"Let 's start the game !", font=('Arial Black', 20),fg="white",bg='#141414')
rolledplayer_label.pack()
nextplayer_label = Label(lastplayer_frame, text = "It is Blue player 's Turn Now.", font=('Arial Black', 20), fg="Blue",bg='#141414')
nextplayer_label.pack()
lastplayer_frame.pack()

#Board
frame = Frame(ws, bg='#141414')

for r in range(15):
    for c in range(15):
        if r in range(6,9) or c in range(6,9):
            Label(frame,height=2,width=3,bg='white',highlightbackground="#141414",highlightthickness=1).grid(row=r,column=c)
        else:
            Label(frame,height=2,width=3,bg='yellow',highlightbackground="#141414",highlightthickness=1).grid(row=r,column=c)

for i in range(1,6):
    Label(frame,height=2,width=3,bg='blue',highlightbackground="#141414",highlightthickness=1).grid(row=7,column=i)
    Label(frame,height=2,width=3,bg='green',highlightbackground="#141414",highlightthickness=1).grid(row=7,column=(i+8))
    Label(frame,height=2,width=3,bg='red',highlightbackground="#141414",highlightthickness=1).grid(row=i,column=7)
    Label(frame,height=2,width=3,bg='violet',highlightbackground="#141414",highlightthickness=1).grid(row=(i+8),column=7)

for j in range(6,9):
    for k in range(6,9):
        Label(frame,height=2,width=3,bg='yellow',highlightbackground="#141414",highlightthickness=1).grid(row=j,column=k)

Label(frame,height=2,width=3,bg='blue',highlightbackground="#141414",highlightthickness=1).grid(row=6,column=1)
Label(frame,height=2,width=3,bg='green',highlightbackground="#141414",highlightthickness=1).grid(row=8,column=13)
Label(frame,height=2,width=3,bg='red',highlightbackground="#141414",highlightthickness=1).grid(row=1,column=8)
Label(frame,height=2,width=3,bg='violet',highlightbackground="#141414",highlightthickness=1).grid(row=13,column=6)
Label(frame, text="Win", bg='orange', height=2, width=3).grid(row=7, column=7)

#coins
i1= PhotoImage(file='Blue.png')
a1=Label( frame, bg='white', height=20,width=20, image=i1 )
a1.grid(row=1,column=1)
b1=Label( frame, bg='white', height=20,width=20, image=i1 )
b1.grid(row=1,column=4)
c1=Label( frame, bg='white', height=20,width=20, image=i1 )
c1.grid(row=4,column=1)
d1=Label( frame, bg='white', height=20,width=20, image=i1 )
d1.grid(row=4,column=4)
i2 = PhotoImage(file='Red.png')
a2=Label( frame, bg='white', height=20,width=20, image=i2 )
a2.grid(row=1,column=10)
b2=Label( frame, bg='white', height=20,width=20, image=i2 )
b2.grid(row=1,column=13)
c2=Label( frame, bg='white', height=20,width=20, image=i2 )
c2.grid(row=4,column=10)
d2=Label( frame, bg='white', height=20,width=20, image=i2 )
d2.grid(row=4,column=13)
i3=PhotoImage(file='Green.png')
a3=Label( frame, bg='white', height=20,width=20, image=i3 )
a3.grid(row=10,column=10)
b3=Label( frame, bg='white', height=20,width=20, image=i3 )
b3.grid(row=10,column=13)
c3=Label( frame, bg='white', height=20,width=20, image=i3 )
c3.grid(row=13,column=10)
d3=Label( frame, bg='white', height=20,width=20, image=i3 )
d3.grid(row=13,column=13)
i4=PhotoImage(file='Violet.png')
a4=Label( frame, bg='white', height=20,width=20, image=i4 )
a4.grid(row=10,column=1)
b4=Label( frame, bg='white', height=20,width=20, image=i4 )
b4.grid(row=10,column=4)
c4=Label( frame, bg='white', height=20,width=20, image=i4 )
c4.grid(row=13,column=1)
d4=Label( frame, bg='white', height=20,width=20, image=i4 )
d4.grid(row=13,column=4)

frame.pack(expand=True)

#Player info
players=('Blue','Red','Green','Violet')
coins={'Blue':[a1,b1,c1,d1],'Red':[a2,b2,c2,d2],'Green':[a3,b3,c3,d3],'Violet':[a4,b4,c4,d4]}
path={'Blue':((6,1),(6,2),(6,3),(6,4),(6,5),(5,6),(4,6),(3,6),(2,6),(1,6),(0,6),(0,7),(0,8),(1,8),(2,8),(3,8),(4,8),(5,8),(6,9),(6,10),(6,11),(6,12),(6,13),(6,14),(7,14),(8,14),(8,13),(8,12),(8,11),(8,10),(8,9),(9,8),(10,8),(11,8),(12,8),(13,8),(14,8),(14,7),(14,6),(13,6),(12,6),(11,6),(10,6),(9,6),(8,5),(8,4),(8,3),(8,2),(8,1),(8,0),(7,0),(7,1),(7,2),(7,3),(7,4),(7,5),(7,6)),
      'Red':((1,8),(2,8),(3,8),(4,8),(5,8),(6,9),(6,10),(6,11),(6,12),(6,13),(6,14),(7,14),(8,14),(8,13),(8,12),(8,11),(8,10),(8,9),(9,8),(10,8),(11,8),(12,8),(13,8),(14,8),(14,7),(14,6),(13,6),(12,6),(11,6),(10,6),(9,6),(8,5),(8,4),(8,3),(8,2),(8,1),(8,0),(7,0),(6,1),(6,2),(6,3),(6,4),(6,5),(5,6),(4,6),(3,6),(2,6),(1,6),(0,6),(0,7),(1,7),(2,7),(3,7),(4,7),(5,7),(6,7)),
      'Green':((8,13),(8,12),(8,11),(8,10),(8,9),(9,8),(10,8),(11,8),(12,8),(13,8),(14,8),(14,7),(14,6),(13,6),(12,6),(11,6),(10,6),(9,6),(8,5),(8,4),(8,3),(8,2),(8,1),(8,0),(7,0),(6,1),(6,2),(6,3),(6,4),(6,5),(5,6),(4,6),(3,6),(2,6),(1,6),(0,6),(0,7),(1,8),(2,8),(3,8),(4,8),(5,8),(6,9),(6,10),(6,11),(6,12),(6,13),(6,14),(7,14),(7,13),(7,12),(7,11),(7,10),(7,9),(7,8)),
      'Violet':((13,6),(12,6),(11,6),(10,6),(9,6),(8,5),(8,4),(8,3),(8,2),(8,1),(8,0),(7,0),(6,1),(6,2),(6,3),(6,4),(6,5),(5,6),(4,6),(3,6),(2,6),(1,6),(0,6),(0,7),(1,8),(2,8),(3,8),(4,8),(5,8),(6,9),(6,10),(6,11),(6,12),(6,13),(6,14),(7,14),(8,14),(8,13),(8,12),(8,11),(8,10),(8,9),(9,8),(10,8),(11,8),(12,8),(13,8),(14,8),(14,7),(13,7),(12,7),(11,7),(10,7),(9,7),(8,7))}
home={'Blue':[(1,1),(1,4),(4,1),(4,4)], 'Red':[(1,10),(1,13),(4,10),(4,13)],
      'Green':[(10,10),(10,13),(13,13),(13,10)], 'Violet':[(10,1),(10,4),(13,4),(13,1)]}
coin_home={'Blue':[a1,b1,c1,d1], 'Red':[a2,b2,c2,d2],
           'Green':[a3,b3,c3,d3], 'Violet':[a4,b4,c4,d4]}
coin_move={'Blue':[],'Red':[],'Green':[],'Violet':[]}
winners=[]

#find grid of lable
def igrid(l):
    d=dict(l.grid_info())
    tup=(d['row'],d['column'])
    return(tup)

#gameplay
last_player = "Violet"
def roll_dice():
    global last_player
    if last_player == players[-1]:
        last_player = players[0]
    else:
        last_p_index = players.index(last_player)
        last_player = players[last_p_index + 1]
    p = last_player
    dice_codes = ['\u2680', '\u2681','\u2682', '\u2683','\u2684', '\u2685']
    numbers = {'\u2680': 1, '\u2681': 2,'\u2682': 3, '\u2683': 4,'\u2684': 5, '\u2685': 6}
    if p=="Blue":
        n="Red"
    elif p=="Red":
        n="Green"
    elif p=="Green":
        n="Violet"
    elif p=="Violet":
        n="Blue"
        
        #dice    
    d = random.choice(dice_codes)
    if d in numbers.keys():
        d_number = numbers[d]
    dice.config(text=d)
    dice_number.config(text=d_number)
    lastplayer_frame = Frame(ws)
    rolledplayer_label.config(text=f"{p} player rolled {d_number}.", fg=p)
    nextplayer_label.config(text=f"It is {n} player 's turn Now.", fg=n)

#movement
    players_up=['Blue','Red','Green','Violet']
    players_up.remove(p)
    if d_number==1 and coin_home[p]!=[]:
        c=coin_home[p][0]
        c.grid(row=path[p][0][0],column=path[p][0][1])
    else:
        c=coin_move[p][0]
        for i in coin_move[p]:
            x=path[p].index((igrid(i)))
            for j in players_up:
                for k in coin_move[j]:
                    if igrid(k) in path[p]:
                        y=path[p].index(igrid(k))
                        if y==(x+d_number):
                            c=i                              
        end=path[p][-d_number::]
        if igrid(c) in end and d_number>=len(end):
            l=list(coin_move[p])
            l.remove(c)
            c=l[0]
        cindex=path[p].index(igrid(c))+d_number
        gr=path[p][cindex]
        c.grid(row=gr[0],column=gr[1])

        #Strike
    op={}
    for i in players_up:
        op[i]=coin_move[i]
    for j in op:
        for oc in op[j]:
            if igrid(c)==igrid(oc):
                ind=coins[j].index(oc)
                ret=home[j][ind]
                oc.grid(row=ret[0],column=ret[1])
                coin_home[j].append(oc)
                coin_move[j].remove(oc)
        
        #Position update
    for i in (coin_home[p]):
        if igrid(i) in home[p]:
            pass
        elif igrid(i) not in home[p]:
            coin_move[p].append(i)
            coin_home[p].remove(i)
            
            
        #win point
    for i in (coins[p]):
        if igrid(i)==(7,6):
            coins[p].remove(i)
            coin_move[p].remove(i)
        elif igrid(i)==(6,7):
            coins[p].remove(i)
            coin_move[p].remove(i)
        elif igrid(i)==(7,8):
            coins[p].remove(i)
            coin_move[p].remove(i)
        elif igrid(i)==(8,7):
            coins[p].remove(i)
            coin_move[p].remove(i)
        
        #win check
    if coins[p]==[]:
        frame1=Frame(ws)
        frame.pack()
        popup_win=Toplevel()
        popup_win.wm_title("Winner !")
        l=Label(popup_win, font=('ariel', 50),text=(p+"Player is a winner !"), fg=p)
        l.grid(row=2,column=2)
        winners.append(p)
        
        #Looser
    if len(winners)==3:
        ply=list(players)
        for i in winners:
            ply.remove(i)
        looser=ply[0]
        frame1=Frame(ws)
        frame.pack()
        popup_win=Toplevel()
        popup_win.wm_title("Looser")
        l=Label(popup_win, font=('ariel', 50),text=(looser+"player lost the game :("), fg=looser)
        l.grid(row=2,column=2)
        
       
#dice box
popup_win = Toplevel()
popup_win.wm_title("Roll The Dice!")
dice = Label(popup_win, font=('ariel', 150), fg='#141414')
dice.grid(row=1, column=20)
dice_number = Label(popup_win, font=('ariel', 20))
dice_number.grid(row=2, column=20)
button = Button(popup_win, text='Roll Dice', font=('ariel', 24),
                relief=GROOVE, bg='grey', command=roll_dice)
button.grid(row=11,column=20)


ws.mainloop()
