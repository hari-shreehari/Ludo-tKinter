import tkinter
from tkinter import *
from tkinter import messagebox
import random

ws = Tk()
ws.title('Ludo')
ws.geometry('1920x1080')
ws.config(bg='#141414')

#message
messagebox.showinfo("Instructions : ",
                    '''Game proceded with your turn followed by computer's
Dice should roll 1 to take a coin out
You are the Blue player and Red player is the computer
No 2nd chance of dice roll is provided for any number cast on dice
You will be allowed to choose the coin to move if possible
You are also provided with an advantage at end phase of game;
ie: You can get your coin to win point even with dice roll higher than required
Let's start the game
Wishing you good luck!  Happy gaming !''')

#play turn
lastplayer_frame = Frame(ws,bg='#141414',highlightbackground="yellow",highlightthickness=4)
blueplayer_label = Label(lastplayer_frame, text = "   You rolled : --   ", font=('Arial Black', 20),fg="Blue",bg='#141414',highlightthickness=2,highlightbackground="yellow")
blueplayer_label.grid(row=0,column=0)
redplayer_label = Label(lastplayer_frame, text = "   Computer rolled : --   ", font=('Arial Black', 20),fg="Red",bg='#141414',highlightthickness=2,highlightbackground="yellow")
redplayer_label.grid(row=0,column=3)
nextplayer_label = Label(lastplayer_frame, text = "It is Blue player 's Turn Now.", font=('Arial Black', 20), fg="Blue",bg='#141414')
nextplayer_label.grid(row=1,columnspan=4)

lastplayer_frame.pack()

#Board
frame = Frame(ws, bg='#141414')

for r in range(15):
    for c in range(15):
        if r in range(6,9) or c in range(6,9):
            Label(frame,height=2,width=3,bg='white',highlightbackground="#141414",highlightthickness=1).grid(row=r,column=c)
        else:
            Label(frame,height=2,width=3,bg='yellow',highlightbackground="#141414",highlightthickness=1).grid(row=r,column=c)

for i in range(1,6):
    Label(frame,height=2,width=3,bg='blue',highlightbackground="#141414",highlightthickness=1).grid(row=7,column=i)
    Label(frame,height=2,width=3,bg='Red',highlightbackground="#141414",highlightthickness=1).grid(row=7,column=(i+8))

for j in range(6,9):
    for k in range(6,9):
        Label(frame,height=2,width=3,bg='yellow',highlightbackground="#141414",highlightthickness=1).grid(row=j,column=k)

Label(frame,height=2,width=3,bg='blue',highlightbackground="#141414",highlightthickness=1).grid(row=6,column=1)
Label(frame,height=2,width=3,bg='Red',highlightbackground="#141414",highlightthickness=1).grid(row=8,column=13)
Label(frame, text="Win", bg='orange', height=2, width=3).grid(row=7, column=7)

#coins
i1= PhotoImage(file='Blue1.png')
i2= PhotoImage(file='Blue2.png')
i3= PhotoImage(file='Blue3.png')
i4= PhotoImage(file='Blue4.png')
a1=Label( frame, bg='white', height=20,width=20, image=i1 )
a1.grid(row=1,column=1)
b1=Label( frame, bg='white', height=20,width=20, image=i2 )
b1.grid(row=1,column=4)
c1=Label( frame, bg='white', height=20,width=20, image=i3 )
c1.grid(row=4,column=1)
d1=Label( frame, bg='white', height=20,width=20, image=i4 )
d1.grid(row=4,column=4)
i5=PhotoImage(file='Red.png')
a3=Label( frame, bg='white', height=20,width=20, image=i5 )
a3.grid(row=10,column=10)
b3=Label( frame, bg='white', height=20,width=20, image=i5 )
b3.grid(row=10,column=13)
c3=Label( frame, bg='white', height=20,width=20, image=i5 )
c3.grid(row=13,column=10)
d3=Label( frame, bg='white', height=20,width=20, image=i5 )
d3.grid(row=13,column=13)

frame.pack(expand=True)

#Player info
players=('Blue','Red')
coins={'Blue':[a1,b1,c1,d1],'Red':[a3,b3,c3,d3]}
B_coin={1:a1,2:b1,3:c1,4:d1}
path={'Blue':((6,1),(6,2),(6,3),(6,4),(6,5),(5,6),(4,6),(3,6),(2,6),(1,6),(0,6),(0,7),(0,8),(1,8),(2,8),(3,8),(4,8),(5,8),(6,9),(6,10),(6,11),(6,12),(6,13),(6,14),(7,14),(8,14),(8,13),(8,12),(8,11),(8,10),(8,9),(9,8),(10,8),(11,8),(12,8),(13,8),(14,8),(14,7),(14,6),(13,6),(12,6),(11,6),(10,6),(9,6),(8,5),(8,4),(8,3),(8,2),(8,1),(8,0),(7,0),(7,1),(7,2),(7,3),(7,4),(7,5),(7,6)),
      'Red':((8,13),(8,12),(8,11),(8,10),(8,9),(9,8),(10,8),(11,8),(12,8),(13,8),(14,8),(14,7),(14,6),(13,6),(12,6),(11,6),(10,6),(9,6),(8,5),(8,4),(8,3),(8,2),(8,1),(8,0),(7,0),(6,1),(6,2),(6,3),(6,4),(6,5),(5,6),(4,6),(3,6),(2,6),(1,6),(0,6),(0,7),(1,8),(2,8),(3,8),(4,8),(5,8),(6,9),(6,10),(6,11),(6,12),(6,13),(6,14),(7,14),(7,13),(7,12),(7,11),(7,10),(7,9),(7,8))}
home={'Blue':[(1,1),(1,4),(4,1),(4,4)], 'Red':[(10,10),(10,13),(13,13),(13,10)]}
coin_home={'Blue':[a1,b1,c1,d1], 'Red':[a3,b3,c3,d3]}
coin_move={'Blue':[],'Red':[]}
winners=[]


#Position update
def pos_update(p):
    for i in (coin_home[p]):
        if igrid(i) in home[p]:
            pass
        elif igrid(i) not in home[p]:
            coin_move[p].append(i)
            coin_home[p].remove(i)
            
#win point
def win_point(p):            
    for i in (coins[p]):
        if igrid(i)==(7,6):
            coins[p].remove(i)
            coin_move[p].remove(i)
        elif igrid(i)==(7,8):
            coins[p].remove(i)
            coin_move[p].remove(i)

#win check
def win_check(p):
    if coins[p]==[]:
        frame1=Frame(ws)
        frame.pack()
        popup_win=Toplevel()
        popup_win.wm_title("Winner !")
        if p=='Blue':
            l=Label(popup_win, font=('ariel', 50),text=("You are the winner !"), fg=p)
        elif p=='Red':
            l=Label(popup_win, font=('ariel', 50),text=("You lost the game :( \n Better luck next time !"), fg=p)            
        l.grid(row=2,column=2)
        winners.append(p)
        

#find grid of lable
def igrid(l):
    d=dict(l.grid_info())
    tup=(d['row'],d['column'])
    return(tup)

#End phase
def find_the_best_index(iterable, index):
    for i in range(index, -1, -1):
        try:
            iterable[i]
            return i
        except:
            continue

#Coin Cut
def strike(p, n):
    for cp in coin_move[p]:
        for oc in coin_move[n]:
            if igrid(c)==igrid(oc):
                ind=coins[n].index(oc)
                ret=home[n][ind]
                oc.grid(row=ret[0],column=ret[1])
                coin_home[n].append(oc)
                coin_move[n].remove(oc)

#make updation
def do_everything(p, n):
    strike(p, n)
    pos_update(p)
    win_point(p)
    win_check(p)

#coin to move
def submit():
    global c, gr, cindex, frozen, choice, popup_win_choice
    val = int(choice.get())
    c = B_coin[val]
    if c not in coins["Blue"]:
        return
    cindex=path[p].index(igrid(c))+d_number
    cindex = find_the_best_index(path[p],cindex)
    gr=path[p][cindex]
    c.grid(row=gr[0],column=gr[1])
    do_everything("Blue", "Red")
    frozen = False
    popup_win_choice.destroy()
    roll_dice()

#Coin to move selection
def create_popup():
    global c, gr, cindex, frozen, p, d_number, choice, popup_win_choice
    if len(coin_move[p])>=2:
        if d_number==1 and coin_home[p]!=[]:
            c=coin_home[p][0]
            c.grid(row=path[p][0][0],column=path[p][0][1])
            do_everything("Blue", "Red")

        elif (d_number==1 and coin_home[p]==[] ) or d_number != 1:
            frozen = True
            popup_win_choice = Toplevel()
            popup_win_choice.wm_title("Coins")
            choice = tkinter.StringVar(popup_win_choice)
            choice.set(f"Select a coin to move {d_number} boxes:")
            option=[str(i) for i in B_coin.keys()]
            question_menu = tkinter.OptionMenu(popup_win_choice, choice, *option)
            question_menu.pack()
            submit_button = tkinter.Button(popup_win_choice, text='Submit', command=submit)
            submit_button.pack()
    
    elif len(coin_move[p])==1:
        if d_number==1 and coin_home[p]!=[]:
            c=coin_home[p][0]
            c.grid(row=path[p][0][0],column=path[p][0][1])
            do_everything("Blue", "Red")
            
        elif d_number!=1:
            c=coin_move[p][0]
            end=path[p][-d_number::]
            if igrid(c) in end and d_number>=len(end):
                c=coin_move[p][find_the_best_index(coin_move[p], 1)]
            cindex=path[p].index(igrid(c))+d_number
            gr=path[p][find_the_best_index(path[p], cindex)]
            c.grid(row=gr[0],column=gr[1])
            do_everything("Blue", "Red")
            
    elif coin_move[p]==[]:
        if d_number==1 and coin_home[p]!=[]:
            c=coin_home[p][0]
            c.grid(row=path[p][0][0],column=path[p][0][1])
            do_everything("Blue", "Red")
    
   
#gameplay
last_player = "Red"
frozen = False
def roll_dice():
    global last_player, c, frozen, p, d_number
    if frozen:
        return
    
    if last_player == players[-1]:
        last_player = players[0]
    else:
        last_p_index = players.index(last_player)
        last_player = players[last_p_index + 1]
    p = last_player
    dice_codes = ['\u2680', '\u2681','\u2682', '\u2683','\u2684', '\u2685']
    numbers = {'\u2680': 1, '\u2681': 2,'\u2682': 3, '\u2683': 4,'\u2684': 5, '\u2685': 6}

    if p=="Blue":
        n="Red"
        
    elif p=="Red":
        n="Blue"
        
#dice    
    d = random.choice(dice_codes)
    if d in numbers.keys():
        d_number = numbers[d]
    dice.config(text=d)
    dice_number.config(text=d_number)
    lastplayer_frame = Frame(ws)
    nextplayer_label.config(text=f"It is {n} player 's turn Now.", fg=n)
    if p=='Blue':
        blueplayer_label.config(text="   You rolled : "+str(d_number)+'   ')
    elif p=='Red':
        redplayer_label.config(text="   Computer rolled : "+str(d_number)+'   ')

#movement
    if p=="Blue":
        create_popup()
        roll_dice()

    elif  p!= "Blue":
        if d_number==1 and coin_home[p]!=[]:
            c=coin_home[p][0]
            c.grid(row=path[p][0][0],column=path[p][0][1])
        elif d_number!=1 or coin_home[p]==[]:
            c=coin_move[p][0]
            end=path[p][-d_number::]
            if igrid(c) in end and d_number>=len(end):
                c=coin_move[p][1]
            cindex=path[p].index(igrid(c))+d_number
            gr=path[p][cindex]
            c.grid(row=gr[0],column=gr[1])
        do_everything(p, n)
            
#dice box
popup_win = Toplevel()
popup_win.wm_title("Roll The Dice!")
dice = Label(popup_win, font=('ariel', 150), fg='#141414')
dice.grid(row=1, column=20)
dice_number = Label(popup_win, font=('ariel', 20))
dice_number.grid(row=2, column=20)
button = Button(popup_win, text='Roll Dice', font=('ariel', 24),
                relief=GROOVE, bg='grey', command=roll_dice)
button.grid(row=11,column=20)


ws.mainloop()
